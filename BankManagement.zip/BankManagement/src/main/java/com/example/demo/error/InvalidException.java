package com.example.demo.error;

public class InvalidException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidException(String s) {
		super(s);
	}
}
