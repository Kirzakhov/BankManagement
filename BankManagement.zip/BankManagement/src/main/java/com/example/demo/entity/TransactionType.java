package com.example.demo.entity;

public enum TransactionType {
	DEPOSIT,
	WITHDRAW,
	TRANSFER
}
